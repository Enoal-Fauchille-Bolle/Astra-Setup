const express = require('express');
const dotenv = require('dotenv');

dotenv.config();

const app = express();

const redirectUrl = process.env.REDIRECT_URL;
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  if (redirectUrl) {
    res.redirect(redirectUrl);
  } else {
    res.status(500).send('REDIRECT_URL is not defined in the .env file.');
  }
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
